﻿namespace IMCSLab_Management
{
    partial class repView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labReport = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.SuspendLayout();
            // 
            // labReport
            // 
            this.labReport.ActiveViewIndex = -1;
            this.labReport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labReport.Cursor = System.Windows.Forms.Cursors.Default;
            this.labReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labReport.Location = new System.Drawing.Point(0, 0);
            this.labReport.Name = "labReport";
            this.labReport.Size = new System.Drawing.Size(663, 444);
            this.labReport.TabIndex = 0;
            this.labReport.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None;
            // 
            // repView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(663, 444);
            this.Controls.Add(this.labReport);
            this.Name = "repView";
            this.Text = "repView";
            this.ResumeLayout(false);

        }

        #endregion

        public CrystalDecisions.Windows.Forms.CrystalReportViewer labReport;


    }
}