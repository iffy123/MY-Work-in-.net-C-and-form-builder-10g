﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMCSLab_Management
{
    public partial class Form2 : Form
    {
        int timeLeft = 0;
        int timeTotal = 0;

        public Form2()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (timeLeft > 0)
            {
                timeLeft--;
                progressBar1.PerformStep();
                int value = progressBar1.Value;
                perLbl.Text = value.ToString();
            }
            else
            {
                timer1.Stop();
                new Form3().Show();
                this.Hide();
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            timeLeft = 20;
            timeTotal = timeLeft;
            progressBar1.Step = 7;
            timer1.Start();

        }
    }
}
