﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace IMCSLab_Management
{
    public partial class LAB_A : UserControl
    {
        SqlCommand cmd;

        //ID variable used in Updating and Deleting Record
        int id = 0;
        public LAB_A()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True");
        private void populate()
        {
            Con.Open();
            string query = "select * from LAB_A";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            MemberSDGV.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (COM.Text != "" && STATE.Text != "")
            {
                SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True");

               cmd = new SqlCommand("update  LAB_A set STATE=@STATE,MAINTAIN=@MAINTAIN, ISSUE=@ISSUE where COM_ID=@Id", Con);
                Con.Open();
                cmd.Parameters.AddWithValue("@Id", COM.Text);
                cmd.Parameters.AddWithValue("@STATE", STATE.Text);
                cmd.Parameters.AddWithValue("@MAINTAIN", MAINTAIN.Text);
                cmd.Parameters.AddWithValue("@ISSUE", ISSUE.Text);
                cmd.ExecuteNonQuery();
                Con.Close();
                MessageBox.Show("Details Updated Successfully");
                populate();
            }
            else
            {
                MessageBox.Show("Please enter mandatory details!");
            }
        }

        private void LAB_A_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            new ADDCOMPUTER().Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            repView rv = new repView();
            rv.Show();
            Con.Open();
            SqlCommand cmd = new SqlCommand("Select * from LAB_A", Con);
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sd.Fill(ds,"LAB_A");
            CrystalReport1 cr = new CrystalReport1();
            cr.SetDataSource(ds);
            rv.labReport.ReportSource = cr;
            rv.labReport.Refresh();
            Con.Close();
            
           
           

        }

        private void MemberSDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
