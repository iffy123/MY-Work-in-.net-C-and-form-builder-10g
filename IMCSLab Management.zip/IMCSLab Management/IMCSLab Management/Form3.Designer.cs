﻿namespace IMCSLab_Management
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.lABAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lABBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lABCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lABAToolStripMenuItem,
            this.lABBToolStripMenuItem,
            this.lABCToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(880, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // lABAToolStripMenuItem
            // 
            this.lABAToolStripMenuItem.Name = "lABAToolStripMenuItem";
            this.lABAToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.lABAToolStripMenuItem.Text = "LAB A";
            this.lABAToolStripMenuItem.Click += new System.EventHandler(this.lABAToolStripMenuItem_Click);
            // 
            // lABBToolStripMenuItem
            // 
            this.lABBToolStripMenuItem.Name = "lABBToolStripMenuItem";
            this.lABBToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.lABBToolStripMenuItem.Text = "LAB B";
            this.lABBToolStripMenuItem.Click += new System.EventHandler(this.lABBToolStripMenuItem_Click);
            // 
            // lABCToolStripMenuItem
            // 
            this.lABCToolStripMenuItem.Name = "lABCToolStripMenuItem";
            this.lABCToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.lABCToolStripMenuItem.Text = "LAB C";
            this.lABCToolStripMenuItem.Click += new System.EventHandler(this.lABCToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.AutoSize = true;
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 24);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(880, 481);
            this.panel1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Crimson;
            this.label1.Location = new System.Drawing.Point(43, 147);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(796, 41);
            this.label1.TabIndex = 0;
            this.label1.Text = "WELCOME TO IMCS LAB MANAGEMENT SYSTEM";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(880, 505);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem lABAToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStripMenuItem lABBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lABCToolStripMenuItem;
        private System.Windows.Forms.Label label1;
    }
}