﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMCSLab_Management
{
    public partial class ADDCOMPUTER : Form
    {
        public ADDCOMPUTER()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True");
        private void button1_Click(object sender, EventArgs e)
        {
            if (ComID.Text == "" || RowID.Text == "" || StateID.Text == "" || TypeID.Text == "")
            {
                MessageBox.Show("Information is Missing");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "insert into LAB_A values('" + ComID.Text + "','" + RowID.Text + "','" + StateID.Text + "', '" + TypeID.Text + "', '" + Maintain.Text + "','" + Issue.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Member Added Successfully");
                    Con.Close();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (ComID.Text == "" || RowID.Text == "" || StateID.Text == "" || TypeID.Text == "")
            {
                MessageBox.Show("Information is Missing");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "insert into LAB_B values('" + ComID.Text + "','" + RowID.Text + "','" + StateID.Text + "', '" + TypeID.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Member Added Successfully");
                    Con.Close();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void ADDCOMPUTER_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (ComID.Text == "" || RowID.Text == "" || StateID.Text == "" || TypeID.Text == "")
            {
                MessageBox.Show("Information is Missing");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "insert into LAB_C values('" + ComID.Text + "','" + RowID.Text + "','" + StateID.Text + "', '" + TypeID.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Member Added Successfully");
                    Con.Close();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
