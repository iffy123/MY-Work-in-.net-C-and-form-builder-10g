﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMCSLab_Management
{
    public partial class crystal_report : Form
    {
        public crystal_report()
        {
            InitializeComponent();
        }
    }
}
