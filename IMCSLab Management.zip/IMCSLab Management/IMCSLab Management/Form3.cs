﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMCSLab_Management
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void lABAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.panel1.Controls.Clear();
            LAB_A up = new LAB_A();
            up.Dock = DockStyle.Fill;
            panel1.Controls.Add(up);

        }

        private void lABBToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.panel1.Controls.Clear();
            LAB_B up = new LAB_B();
            up.Dock = DockStyle.Fill;
            panel1.Controls.Add(up);
        }

        private void lABCToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.panel1.Controls.Clear();
            LAB_C up = new LAB_C();
            up.Dock = DockStyle.Fill;
            panel1.Controls.Add(up);
        }
    }
}
