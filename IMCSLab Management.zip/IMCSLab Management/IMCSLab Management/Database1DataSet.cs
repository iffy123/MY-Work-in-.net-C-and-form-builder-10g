﻿namespace IMCSLab_Management {
    
    
    public partial class Database1DataSet {
    }
}
