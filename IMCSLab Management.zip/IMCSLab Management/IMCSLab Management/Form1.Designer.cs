﻿namespace IMCSLab_Management
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.LOGBTN = new System.Windows.Forms.Button();
            this.REGBTN = new System.Windows.Forms.Button();
            this.EXITBTN = new System.Windows.Forms.Button();
            this.INUSER = new System.Windows.Forms.TextBox();
            this.INPASS = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.IMCS = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LOGBTN
            // 
            this.LOGBTN.BackColor = System.Drawing.Color.DarkRed;
            this.LOGBTN.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.LOGBTN.FlatAppearance.BorderSize = 0;
            this.LOGBTN.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.LOGBTN.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.LOGBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LOGBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LOGBTN.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LOGBTN.Location = new System.Drawing.Point(279, 187);
            this.LOGBTN.Name = "LOGBTN";
            this.LOGBTN.Size = new System.Drawing.Size(135, 37);
            this.LOGBTN.TabIndex = 7;
            this.LOGBTN.Text = "LOGIN";
            this.LOGBTN.UseVisualStyleBackColor = false;
            this.LOGBTN.Click += new System.EventHandler(this.LOGBTN_Click);
            // 
            // REGBTN
            // 
            this.REGBTN.BackColor = System.Drawing.Color.DarkRed;
            this.REGBTN.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.REGBTN.FlatAppearance.BorderSize = 0;
            this.REGBTN.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.REGBTN.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.REGBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.REGBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.REGBTN.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.REGBTN.Location = new System.Drawing.Point(12, 302);
            this.REGBTN.Name = "REGBTN";
            this.REGBTN.Size = new System.Drawing.Size(135, 35);
            this.REGBTN.TabIndex = 8;
            this.REGBTN.Text = "Not a User?";
            this.REGBTN.UseVisualStyleBackColor = false;
            // 
            // EXITBTN
            // 
            this.EXITBTN.BackColor = System.Drawing.Color.DarkRed;
            this.EXITBTN.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.EXITBTN.FlatAppearance.BorderSize = 0;
            this.EXITBTN.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.EXITBTN.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.EXITBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EXITBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EXITBTN.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.EXITBTN.Location = new System.Drawing.Point(512, 302);
            this.EXITBTN.Name = "EXITBTN";
            this.EXITBTN.Size = new System.Drawing.Size(130, 35);
            this.EXITBTN.TabIndex = 9;
            this.EXITBTN.Text = "EXIT ";
            this.EXITBTN.UseVisualStyleBackColor = false;
            this.EXITBTN.Click += new System.EventHandler(this.EXITBTN_Click);
            // 
            // INUSER
            // 
            this.INUSER.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.INUSER.Location = new System.Drawing.Point(211, 80);
            this.INUSER.Name = "INUSER";
            this.INUSER.Size = new System.Drawing.Size(203, 33);
            this.INUSER.TabIndex = 10;
            // 
            // INPASS
            // 
            this.INPASS.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.INPASS.Location = new System.Drawing.Point(211, 123);
            this.INPASS.Name = "INPASS";
            this.INPASS.PasswordChar = '*';
            this.INPASS.Size = new System.Drawing.Size(203, 33);
            this.INPASS.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkRed;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label1.Location = new System.Drawing.Point(96, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 23);
            this.label1.TabIndex = 12;
            this.label1.Text = "UserName";
            // 
            // IMCS
            // 
            this.IMCS.AutoSize = true;
            this.IMCS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.IMCS.Font = new System.Drawing.Font("Microsoft Uighur", 27.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IMCS.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.IMCS.Location = new System.Drawing.Point(54, 9);
            this.IMCS.Name = "IMCS";
            this.IMCS.Size = new System.Drawing.Size(550, 49);
            this.IMCS.TabIndex = 14;
            this.IMCS.Text = "IMCS LABORATORY MANAGEMENT SYSTEM";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkRed;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label2.Location = new System.Drawing.Point(96, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 23);
            this.label2.TabIndex = 15;
            this.label2.Text = "Password";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(654, 349);
            this.ControlBox = false;
            this.Controls.Add(this.label2);
            this.Controls.Add(this.IMCS);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.INPASS);
            this.Controls.Add(this.INUSER);
            this.Controls.Add(this.EXITBTN);
            this.Controls.Add(this.REGBTN);
            this.Controls.Add(this.LOGBTN);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button LOGBTN;
        private System.Windows.Forms.Button REGBTN;
        private System.Windows.Forms.Button EXITBTN;
        private System.Windows.Forms.TextBox INUSER;
        private System.Windows.Forms.TextBox INPASS;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label IMCS;
        private System.Windows.Forms.Label label2;
    }
}

