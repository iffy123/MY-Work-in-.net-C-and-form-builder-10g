﻿-- Insert sample data into Patients table
INSERT INTO Patients (PatientID, FirstName, LastName, DateOfBirth, Gender, ContactNumber, Address, Email)
VALUES
    (1, 'aziz', 'Doe', '1990-05-15', 'Male', '1234567890', '123 Main St', 'john.doe@example.com'),
    (2, 'zeeshan', 'Smith', '1985-10-22', 'Female', '9876543210', '456 Elm St', 'jane.smith@example.com');

-- Insert sample data into Doctors table
INSERT INTO Doctors (DoctorID, FirstName, LastName, DateOfBirth, Gender, ContactNumber, Address, Email, Specialization, Department)
VALUES
    (1, 'Dr. ahmed', 'Johnson', '1978-08-25', 'Male', '5551234567', '789 Oak St', 'michael.johnson@example.com', 'Cardiology', 'Cardiology Department'),
    (2, 'Dr. ahmed', 'Anderson', '1982-03-12', 'male', '5559876543', '321 Pine St', 'emily.anderson@example.com', 'Pediatrics', 'Pediatrics Department');

-- Insert sample data into Appointments table
INSERT INTO Appointments (AppointmentID, PatientID, DoctorID, AppointmentDate, Description)
VALUES
    (1, 1, 1, '2023-06-02 10:00:00', 'Routine check-up'),
    (2, 2, 2, '2023-06-03 14:30:00', 'Vaccination');

-- Insert sample data into Departments table
INSERT INTO Departments (DepartmentID, DepartmentName)
VALUES
    (1, 'Cardiology'),
    (2, 'Pediatrics');

-- Insert sample data into Medicines table
INSERT INTO Medicines (MedicineID, MedicineName, Manufacturer, UnitPrice, QuantityInStock)
VALUES
    (1, 'Aspirin', 'ABC Pharmaceuticals', 5.99, 100),
    (2, 'Amoxicillin', 'XYZ Pharmaceuticals', 10.99, 50);

-- Insert sample data into Bills table
INSERT INTO Bills (BillID, PatientID, TotalAmount, BillDate)
VALUES
    (1, 1, 150.75, '2023-06-05'),
    (2, 2, 75.50, '2023-06-07');
