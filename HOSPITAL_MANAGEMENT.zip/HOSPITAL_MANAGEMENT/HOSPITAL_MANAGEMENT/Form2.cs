﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HOSPITAL_MANAGEMENT
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        int timeLeft = 0;
        int timeTotal = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (timeLeft > 0)
            {
                timeLeft--;
                progressBar1.PerformStep();
                int value = progressBar1.Value;
                perLbl.Text = value.ToString();
            }
            else
            {
                timer1.Stop();
                new Form3().Show();
                this.Hide();
            }

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            timeLeft = 10;
            timeTotal = timeLeft;
            progressBar1.Step = 10;
            timer1.Start();
        }
    }
}
