﻿namespace HOSPITAL_MANAGEMENT
{
    partial class Patients
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.PAT_EM = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.PAT_CN = new System.Windows.Forms.TextBox();
            this.PAT_ADD = new System.Windows.Forms.TextBox();
            this.PAT_GEN = new System.Windows.Forms.TextBox();
            this.PAT_GV = new System.Windows.Forms.DataGridView();
            this.PAT_DOB = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.PAT_FN = new System.Windows.Forms.TextBox();
            this.PAT_LN = new System.Windows.Forms.TextBox();
            this.PAT_ID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.PAT_GV)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(120, 52);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 80;
            this.label4.Text = "gender";
            // 
            // PAT_EM
            // 
            this.PAT_EM.Location = new System.Drawing.Point(430, 66);
            this.PAT_EM.Name = "PAT_EM";
            this.PAT_EM.Size = new System.Drawing.Size(100, 20);
            this.PAT_EM.TabIndex = 79;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(352, 50);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 13);
            this.label8.TabIndex = 77;
            this.label8.Text = "address";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(240, 50);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(33, 13);
            this.label9.TabIndex = 76;
            this.label9.Text = "name";
            // 
            // PAT_CN
            // 
            this.PAT_CN.Location = new System.Drawing.Point(210, 66);
            this.PAT_CN.Name = "PAT_CN";
            this.PAT_CN.Size = new System.Drawing.Size(100, 20);
            this.PAT_CN.TabIndex = 75;
            // 
            // PAT_ADD
            // 
            this.PAT_ADD.Location = new System.Drawing.Point(324, 66);
            this.PAT_ADD.Name = "PAT_ADD";
            this.PAT_ADD.Size = new System.Drawing.Size(100, 20);
            this.PAT_ADD.TabIndex = 74;
            // 
            // PAT_GEN
            // 
            this.PAT_GEN.Location = new System.Drawing.Point(97, 66);
            this.PAT_GEN.Name = "PAT_GEN";
            this.PAT_GEN.Size = new System.Drawing.Size(100, 20);
            this.PAT_GEN.TabIndex = 73;
            // 
            // PAT_GV
            // 
            this.PAT_GV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PAT_GV.Location = new System.Drawing.Point(39, 128);
            this.PAT_GV.Name = "PAT_GV";
            this.PAT_GV.Size = new System.Drawing.Size(576, 164);
            this.PAT_GV.TabIndex = 72;
            // 
            // PAT_DOB
            // 
            this.PAT_DOB.Location = new System.Drawing.Point(430, 29);
            this.PAT_DOB.Name = "PAT_DOB";
            this.PAT_DOB.Size = new System.Drawing.Size(100, 20);
            this.PAT_DOB.TabIndex = 70;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(355, 99);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 69;
            this.button2.Text = "UPDATE";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(247, 99);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 68;
            this.button1.Text = "CREATE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(120, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 67;
            this.label6.Text = "Patient_id";
            // 
            // PAT_FN
            // 
            this.PAT_FN.Location = new System.Drawing.Point(210, 29);
            this.PAT_FN.Name = "PAT_FN";
            this.PAT_FN.Size = new System.Drawing.Size(100, 20);
            this.PAT_FN.TabIndex = 64;
            // 
            // PAT_LN
            // 
            this.PAT_LN.Location = new System.Drawing.Point(324, 29);
            this.PAT_LN.Name = "PAT_LN";
            this.PAT_LN.Size = new System.Drawing.Size(100, 20);
            this.PAT_LN.TabIndex = 63;
            // 
            // PAT_ID
            // 
            this.PAT_ID.Location = new System.Drawing.Point(97, 29);
            this.PAT_ID.Name = "PAT_ID";
            this.PAT_ID.Size = new System.Drawing.Size(100, 20);
            this.PAT_ID.TabIndex = 62;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(207, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 87;
            this.label2.Text = "contact number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(465, 52);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 13);
            this.label5.TabIndex = 86;
            this.label5.Text = "email";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(221, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 13);
            this.label10.TabIndex = 85;
            this.label10.Text = "address";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(453, 13);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(63, 13);
            this.label11.TabIndex = 84;
            this.label11.Text = "date of birth";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(333, 13);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(52, 13);
            this.label13.TabIndex = 82;
            this.label13.Text = "last name";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(221, 13);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(52, 13);
            this.label14.TabIndex = 81;
            this.label14.Text = "first name";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(456, 99);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 88;
            this.button3.Text = "REPORT";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Patients
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.PAT_EM);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.PAT_CN);
            this.Controls.Add(this.PAT_ADD);
            this.Controls.Add(this.PAT_GEN);
            this.Controls.Add(this.PAT_GV);
            this.Controls.Add(this.PAT_DOB);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.PAT_FN);
            this.Controls.Add(this.PAT_LN);
            this.Controls.Add(this.PAT_ID);
            this.Name = "Patients";
            this.Size = new System.Drawing.Size(716, 304);
            this.Load += new System.EventHandler(this.Patients_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PAT_GV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox PAT_EM;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox PAT_CN;
        private System.Windows.Forms.TextBox PAT_ADD;
        private System.Windows.Forms.TextBox PAT_GEN;
        private System.Windows.Forms.DataGridView PAT_GV;
        private System.Windows.Forms.TextBox PAT_DOB;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox PAT_FN;
        private System.Windows.Forms.TextBox PAT_LN;
        private System.Windows.Forms.TextBox PAT_ID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button3;
    }
}
