﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HOSPITAL_MANAGEMENT
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void EXITBTN_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void LOGinBTN_Click(object sender, EventArgs e)
        {

            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("SELECT COUNT(*) FROM LoginTable WHERE USERNAME= '" + INUSER.Text + "' AND PASSWORD = '" + INPASS.Text + "'", conn);

            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() == "1")
            {
                // MessageBox.Show("Login successful");
                this.Hide();
                new Form2().Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("invalid Username or password ");
            }

        }
    }
}
