﻿namespace HOSPITAL_MANAGEMENT
{
    partial class Medicines
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label7 = new System.Windows.Forms.Label();
            this.MED_Q = new System.Windows.Forms.TextBox();
            this.MED_GV = new System.Windows.Forms.DataGridView();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.MED_ID = new System.Windows.Forms.TextBox();
            this.MED_MENUF = new System.Windows.Forms.TextBox();
            this.MED_NAM = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.gender = new System.Windows.Forms.Label();
            this.MED_UP = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.MED_GV)).BeginInit();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(521, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 13);
            this.label7.TabIndex = 78;
            this.label7.Text = "quantity in stock";
            // 
            // MED_Q
            // 
            this.MED_Q.Location = new System.Drawing.Point(507, 25);
            this.MED_Q.Name = "MED_Q";
            this.MED_Q.Size = new System.Drawing.Size(100, 20);
            this.MED_Q.TabIndex = 73;
            // 
            // MED_GV
            // 
            this.MED_GV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MED_GV.Location = new System.Drawing.Point(40, 124);
            this.MED_GV.Name = "MED_GV";
            this.MED_GV.Size = new System.Drawing.Size(576, 164);
            this.MED_GV.TabIndex = 72;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(325, 95);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 69;
            this.button2.Text = "UPDATE";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(217, 95);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 68;
            this.button1.Text = "CREATE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(90, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 67;
            this.label6.Text = "medicines";
            // 
            // MED_ID
            // 
            this.MED_ID.Location = new System.Drawing.Point(67, 25);
            this.MED_ID.Name = "MED_ID";
            this.MED_ID.Size = new System.Drawing.Size(100, 20);
            this.MED_ID.TabIndex = 62;
            // 
            // MED_MENUF
            // 
            this.MED_MENUF.Location = new System.Drawing.Point(294, 25);
            this.MED_MENUF.Name = "MED_MENUF";
            this.MED_MENUF.Size = new System.Drawing.Size(100, 20);
            this.MED_MENUF.TabIndex = 63;
            // 
            // MED_NAM
            // 
            this.MED_NAM.Location = new System.Drawing.Point(180, 25);
            this.MED_NAM.Name = "MED_NAM";
            this.MED_NAM.Size = new System.Drawing.Size(100, 20);
            this.MED_NAM.TabIndex = 64;
            this.MED_NAM.TextChanged += new System.EventHandler(this.MED_NAM_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(210, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 65;
            this.label3.Text = "medicine name";
            // 
            // gender
            // 
            this.gender.AutoSize = true;
            this.gender.Location = new System.Drawing.Point(322, 9);
            this.gender.Name = "gender";
            this.gender.Size = new System.Drawing.Size(69, 13);
            this.gender.TabIndex = 66;
            this.gender.Text = "manufacturer";
            // 
            // MED_UP
            // 
            this.MED_UP.Location = new System.Drawing.Point(400, 25);
            this.MED_UP.Name = "MED_UP";
            this.MED_UP.Size = new System.Drawing.Size(100, 20);
            this.MED_UP.TabIndex = 70;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(423, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 71;
            this.label1.Text = "unit prize";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(425, 95);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 79;
            this.button3.Text = "REPORT";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Medicines
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.MED_Q);
            this.Controls.Add(this.MED_GV);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.MED_UP);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.gender);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.MED_NAM);
            this.Controls.Add(this.MED_MENUF);
            this.Controls.Add(this.MED_ID);
            this.Name = "Medicines";
            this.Size = new System.Drawing.Size(657, 297);
            this.Load += new System.EventHandler(this.Medicines_Load);
            ((System.ComponentModel.ISupportInitialize)(this.MED_GV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox MED_Q;
        private System.Windows.Forms.DataGridView MED_GV;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox MED_ID;
        private System.Windows.Forms.TextBox MED_MENUF;
        private System.Windows.Forms.TextBox MED_NAM;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label gender;
        private System.Windows.Forms.TextBox MED_UP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
    }
}
