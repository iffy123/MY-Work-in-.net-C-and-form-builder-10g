﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HOSPITAL_MANAGEMENT
{
    public partial class bills : UserControl
    {
        public bills()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True");

        private void populate()
        {
            Con.Open();
            string query = "select * from BILLS";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            BILL_GRIDVIEW.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
 if (BILL_iD.Text == "" || BILL_PAT_ID.Text == "" || BILL_TOTALAMT.Text == "" || BILL_DATE.Text == "")
            {
                MessageBox.Show("Information is Missing");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "insert into BILLS values('" + BILL_iD.Text + "','" + BILL_PAT_ID.Text + "','" + BILL_TOTALAMT.Text + "', '" + BILL_DATE.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("data added ");
                    Con.Close();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
                Con.Close();
            }
        }

        private void bills_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (BILL_DATE.Text != "" && BILL_iD.Text != "")
            {
                SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True");

                cmd = new SqlCommand("update  BILLS set PATIENTID=@PI, TOTALAMOUNT=@TOTL,BILLDATE=@BILLDAT where BILLID=@Id", Con);
                Con.Open();
                cmd.Parameters.AddWithValue("@Id", BILL_iD.Text);
                cmd.Parameters.AddWithValue("@PI", BILL_PAT_ID.Text);
                cmd.Parameters.AddWithValue("@BILLDAT", BILL_DATE.Text);
                cmd.Parameters.AddWithValue("@TOTL", BILL_TOTALAMT.Text);
                
                cmd.ExecuteNonQuery();
                Con.Close();
                MessageBox.Show("Details Updated Successfully");
                populate();
            }
            else
            {
                MessageBox.Show("Please enter mandatory details!");
            }
        }

        public SqlCommand cmd { get; set; }

        private void button3_Click(object sender, EventArgs e)
        {
            REPORT rv = new REPORT();
            rv.Show();
            Con.Open();
            SqlCommand cmd = new SqlCommand("Select * from bills", Con);
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sd.Fill(ds, "bills");
            CrystalReport2 cr = new CrystalReport2();
            cr.SetDataSource(ds);
            rv.crystalReportViewer1.ReportSource = cr;
            rv.crystalReportViewer1.Refresh();
            Con.Close();
        }
    }
}
