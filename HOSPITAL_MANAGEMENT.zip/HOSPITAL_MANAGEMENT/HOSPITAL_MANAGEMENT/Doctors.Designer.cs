﻿namespace HOSPITAL_MANAGEMENT
{
    partial class Doctors
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DOC_GV = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.DOC_GEN = new System.Windows.Forms.TextBox();
            this.DOC_DFB = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.gender = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.DOC_FN = new System.Windows.Forms.TextBox();
            this.DOC_LN = new System.Windows.Forms.TextBox();
            this.DOC_ID = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.DOC_DEP = new System.Windows.Forms.TextBox();
            this.DOC_SPE = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.DOC_ADDR = new System.Windows.Forms.TextBox();
            this.DOC_EMAL = new System.Windows.Forms.TextBox();
            this.DOC_CNUM = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DOC_GV)).BeginInit();
            this.SuspendLayout();
            // 
            // DOC_GV
            // 
            this.DOC_GV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DOC_GV.Location = new System.Drawing.Point(46, 134);
            this.DOC_GV.Name = "DOC_GV";
            this.DOC_GV.Size = new System.Drawing.Size(576, 164);
            this.DOC_GV.TabIndex = 51;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(429, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 50;
            this.label1.Text = "date of birth";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(520, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 49;
            this.label2.Text = "gender";
            // 
            // DOC_GEN
            // 
            this.DOC_GEN.Location = new System.Drawing.Point(512, 35);
            this.DOC_GEN.Name = "DOC_GEN";
            this.DOC_GEN.Size = new System.Drawing.Size(100, 20);
            this.DOC_GEN.TabIndex = 48;
            // 
            // DOC_DFB
            // 
            this.DOC_DFB.Location = new System.Drawing.Point(406, 35);
            this.DOC_DFB.Name = "DOC_DFB";
            this.DOC_DFB.Size = new System.Drawing.Size(100, 20);
            this.DOC_DFB.TabIndex = 47;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(331, 105);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 46;
            this.button2.Text = "UPDATE";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(223, 105);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 45;
            this.button1.Text = "CREATE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(96, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 13);
            this.label6.TabIndex = 44;
            this.label6.Text = "doctorid";
            // 
            // gender
            // 
            this.gender.AutoSize = true;
            this.gender.Location = new System.Drawing.Point(328, 19);
            this.gender.Name = "gender";
            this.gender.Size = new System.Drawing.Size(52, 13);
            this.gender.TabIndex = 43;
            this.gender.Text = "last name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(216, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 42;
            this.label3.Text = "first name";
            // 
            // DOC_FN
            // 
            this.DOC_FN.Location = new System.Drawing.Point(186, 35);
            this.DOC_FN.Name = "DOC_FN";
            this.DOC_FN.Size = new System.Drawing.Size(100, 20);
            this.DOC_FN.TabIndex = 41;
            // 
            // DOC_LN
            // 
            this.DOC_LN.Location = new System.Drawing.Point(300, 35);
            this.DOC_LN.Name = "DOC_LN";
            this.DOC_LN.Size = new System.Drawing.Size(100, 20);
            this.DOC_LN.TabIndex = 40;
            // 
            // DOC_ID
            // 
            this.DOC_ID.Location = new System.Drawing.Point(73, 35);
            this.DOC_ID.Name = "DOC_ID";
            this.DOC_ID.Size = new System.Drawing.Size(100, 20);
            this.DOC_ID.TabIndex = 39;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(429, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 13);
            this.label4.TabIndex = 61;
            this.label4.Text = "specialization";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(520, 56);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 13);
            this.label5.TabIndex = 60;
            this.label5.Text = "department";
            // 
            // DOC_DEP
            // 
            this.DOC_DEP.Location = new System.Drawing.Point(512, 72);
            this.DOC_DEP.Name = "DOC_DEP";
            this.DOC_DEP.Size = new System.Drawing.Size(100, 20);
            this.DOC_DEP.TabIndex = 59;
            // 
            // DOC_SPE
            // 
            this.DOC_SPE.Location = new System.Drawing.Point(406, 72);
            this.DOC_SPE.Name = "DOC_SPE";
            this.DOC_SPE.Size = new System.Drawing.Size(100, 20);
            this.DOC_SPE.TabIndex = 58;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(96, 56);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 13);
            this.label7.TabIndex = 57;
            this.label7.Text = "contact number";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(328, 56);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 13);
            this.label8.TabIndex = 56;
            this.label8.Text = "email";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(216, 56);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 13);
            this.label9.TabIndex = 55;
            this.label9.Text = "address";
            // 
            // DOC_ADDR
            // 
            this.DOC_ADDR.Location = new System.Drawing.Point(186, 72);
            this.DOC_ADDR.Name = "DOC_ADDR";
            this.DOC_ADDR.Size = new System.Drawing.Size(100, 20);
            this.DOC_ADDR.TabIndex = 54;
            // 
            // DOC_EMAL
            // 
            this.DOC_EMAL.Location = new System.Drawing.Point(300, 72);
            this.DOC_EMAL.Name = "DOC_EMAL";
            this.DOC_EMAL.Size = new System.Drawing.Size(100, 20);
            this.DOC_EMAL.TabIndex = 53;
            // 
            // DOC_CNUM
            // 
            this.DOC_CNUM.Location = new System.Drawing.Point(73, 72);
            this.DOC_CNUM.Name = "DOC_CNUM";
            this.DOC_CNUM.Size = new System.Drawing.Size(100, 20);
            this.DOC_CNUM.TabIndex = 52;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(432, 105);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 62;
            this.button3.Text = "REPORT";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Doctors
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.DOC_DEP);
            this.Controls.Add(this.DOC_SPE);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.DOC_ADDR);
            this.Controls.Add(this.DOC_EMAL);
            this.Controls.Add(this.DOC_CNUM);
            this.Controls.Add(this.DOC_GV);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.DOC_GEN);
            this.Controls.Add(this.DOC_DFB);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.gender);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.DOC_FN);
            this.Controls.Add(this.DOC_LN);
            this.Controls.Add(this.DOC_ID);
            this.Name = "Doctors";
            this.Size = new System.Drawing.Size(674, 301);
            this.Load += new System.EventHandler(this.Doctors_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DOC_GV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DOC_GV;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox DOC_GEN;
        private System.Windows.Forms.TextBox DOC_DFB;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label gender;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox DOC_FN;
        private System.Windows.Forms.TextBox DOC_LN;
        private System.Windows.Forms.TextBox DOC_ID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox DOC_DEP;
        private System.Windows.Forms.TextBox DOC_SPE;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox DOC_ADDR;
        private System.Windows.Forms.TextBox DOC_EMAL;
        private System.Windows.Forms.TextBox DOC_CNUM;
        private System.Windows.Forms.Button button3;
    }
}
