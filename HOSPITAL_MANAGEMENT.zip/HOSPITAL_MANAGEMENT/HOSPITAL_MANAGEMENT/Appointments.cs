﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HOSPITAL_MANAGEMENT
{
    public partial class Appointments : UserControl
    {
        public Appointments()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True");

        private void populate()
        {
            Con.Open();
            string query = "select * from APPOINTMENTS";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            AP_DATAGV.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (AP_ID.Text == "" || AP_PAT_ID.Text == "" || AP_DOC_ID.Text == "" || AP_DATE.Text == "")
            {
                MessageBox.Show("Information is Missing");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "insert into appointments values('" + AP_ID.Text + "','" + AP_PAT_ID.Text + "','" + AP_DOC_ID.Text + "', '" + AP_DATE.Text + "', '" + AP_DEC.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("INSERTED");
                    
                    Con.Close();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
                Con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
       if (AP_ID.Text != "" && AP_DOC_ID.Text != "")
            {
                SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True");

                cmd = new SqlCommand("update  APPOINTMents set PATIENTid=@PI, DOCTORid=@DSI,APPOINTMENTDATE=@APD,DESCRIPTION=@AD where APPOINTMENTID=@Id", Con);
                Con.Open();
                cmd.Parameters.AddWithValue("@Id", AP_ID.Text);
                cmd.Parameters.AddWithValue("@PI", AP_PAT_ID.Text);
                cmd.Parameters.AddWithValue("@DSI", AP_DOC_ID.Text);
                cmd.Parameters.AddWithValue("@APD", AP_DATE.Text);
                cmd.Parameters.AddWithValue("@AD", AP_DEC.Text);
                
                cmd.ExecuteNonQuery();
                Con.Close();
                MessageBox.Show("Details Updated Successfully");
                populate();
            }
            else
            {
                MessageBox.Show("Please enter mandatory details!");
            }
        }

        private void Appointments_Load(object sender, EventArgs e)
        {
            populate();
        }

        public SqlCommand cmd { get; set; }

        private void button3_Click(object sender, EventArgs e)
        {
            REPORT rv = new REPORT();
            rv.Show();
            Con.Open();
            SqlCommand cmd = new SqlCommand("Select * from appointments", Con);
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sd.Fill(ds, "appointments");
            CrystalReport1 cr = new CrystalReport1();
            cr.SetDataSource(ds);
            rv.crystalReportViewer1.ReportSource = cr;
            rv.crystalReportViewer1.Refresh();
            Con.Close();
        }
    }
}
