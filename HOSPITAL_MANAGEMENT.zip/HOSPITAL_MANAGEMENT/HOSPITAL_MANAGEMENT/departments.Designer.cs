﻿namespace HOSPITAL_MANAGEMENT
{
    partial class departments
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DEP_GRD = new System.Windows.Forms.DataGridView();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.DEP_NAM = new System.Windows.Forms.TextBox();
            this.DEP_ID = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DEP_GRD)).BeginInit();
            this.SuspendLayout();
            // 
            // DEP_GRD
            // 
            this.DEP_GRD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DEP_GRD.Location = new System.Drawing.Point(47, 114);
            this.DEP_GRD.Name = "DEP_GRD";
            this.DEP_GRD.Size = new System.Drawing.Size(576, 164);
            this.DEP_GRD.TabIndex = 51;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(329, 85);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 46;
            this.button2.Text = "UPDATE";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(221, 85);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 45;
            this.button1.Text = "CREATE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(221, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 13);
            this.label6.TabIndex = 44;
            this.label6.Text = "department_Id";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(328, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 13);
            this.label3.TabIndex = 42;
            this.label3.Text = "department_name";
            // 
            // DEP_NAM
            // 
            this.DEP_NAM.Location = new System.Drawing.Point(323, 31);
            this.DEP_NAM.Name = "DEP_NAM";
            this.DEP_NAM.Size = new System.Drawing.Size(100, 20);
            this.DEP_NAM.TabIndex = 41;
            // 
            // DEP_ID
            // 
            this.DEP_ID.Location = new System.Drawing.Point(210, 31);
            this.DEP_ID.Name = "DEP_ID";
            this.DEP_ID.Size = new System.Drawing.Size(100, 20);
            this.DEP_ID.TabIndex = 39;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(435, 85);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 53;
            this.button3.Text = "REPORT";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // departments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button3);
            this.Controls.Add(this.DEP_GRD);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.DEP_NAM);
            this.Controls.Add(this.DEP_ID);
            this.Name = "departments";
            this.Size = new System.Drawing.Size(671, 294);
            this.Load += new System.EventHandler(this.departments_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DEP_GRD)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DEP_GRD;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox DEP_NAM;
        private System.Windows.Forms.TextBox DEP_ID;
        private System.Windows.Forms.Button button3;
    }
}
