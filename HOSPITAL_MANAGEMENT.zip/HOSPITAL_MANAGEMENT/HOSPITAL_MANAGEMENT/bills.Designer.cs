﻿namespace HOSPITAL_MANAGEMENT
{
    partial class bills
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BILL_GRIDVIEW = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.BILL_DATE = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.gender = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BILL_PAT_ID = new System.Windows.Forms.TextBox();
            this.BILL_TOTALAMT = new System.Windows.Forms.TextBox();
            this.BILL_iD = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.BILL_GRIDVIEW)).BeginInit();
            this.SuspendLayout();
            // 
            // BILL_GRIDVIEW
            // 
            this.BILL_GRIDVIEW.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.BILL_GRIDVIEW.Location = new System.Drawing.Point(39, 118);
            this.BILL_GRIDVIEW.Name = "BILL_GRIDVIEW";
            this.BILL_GRIDVIEW.Size = new System.Drawing.Size(576, 164);
            this.BILL_GRIDVIEW.TabIndex = 51;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(419, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 50;
            this.label1.Text = "BILL DATE";
            // 
            // BILL_DATE
            // 
            this.BILL_DATE.Location = new System.Drawing.Point(396, 36);
            this.BILL_DATE.Name = "BILL_DATE";
            this.BILL_DATE.Size = new System.Drawing.Size(100, 20);
            this.BILL_DATE.TabIndex = 47;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(321, 89);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 46;
            this.button2.Text = "UPDATE";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(213, 89);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 45;
            this.button1.Text = "CREATE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(86, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 13);
            this.label6.TabIndex = 44;
            this.label6.Text = "BILL ID";
            // 
            // gender
            // 
            this.gender.AutoSize = true;
            this.gender.Location = new System.Drawing.Point(318, 20);
            this.gender.Name = "gender";
            this.gender.Size = new System.Drawing.Size(92, 13);
            this.gender.TabIndex = 43;
            this.gender.Text = "TOTAL AMOUNT";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(206, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 42;
            this.label3.Text = "PATIENT ID";
            // 
            // BILL_PAT_ID
            // 
            this.BILL_PAT_ID.Location = new System.Drawing.Point(176, 36);
            this.BILL_PAT_ID.Name = "BILL_PAT_ID";
            this.BILL_PAT_ID.Size = new System.Drawing.Size(100, 20);
            this.BILL_PAT_ID.TabIndex = 41;
            // 
            // BILL_TOTALAMT
            // 
            this.BILL_TOTALAMT.Location = new System.Drawing.Point(290, 36);
            this.BILL_TOTALAMT.Name = "BILL_TOTALAMT";
            this.BILL_TOTALAMT.Size = new System.Drawing.Size(100, 20);
            this.BILL_TOTALAMT.TabIndex = 40;
            // 
            // BILL_iD
            // 
            this.BILL_iD.Location = new System.Drawing.Point(63, 36);
            this.BILL_iD.Name = "BILL_iD";
            this.BILL_iD.Size = new System.Drawing.Size(100, 20);
            this.BILL_iD.TabIndex = 39;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(421, 89);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 53;
            this.button3.Text = "REPORT";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // bills
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button3);
            this.Controls.Add(this.BILL_GRIDVIEW);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BILL_DATE);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.gender);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.BILL_PAT_ID);
            this.Controls.Add(this.BILL_TOTALAMT);
            this.Controls.Add(this.BILL_iD);
            this.Name = "bills";
            this.Size = new System.Drawing.Size(655, 302);
            this.Load += new System.EventHandler(this.bills_Load);
            ((System.ComponentModel.ISupportInitialize)(this.BILL_GRIDVIEW)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView BILL_GRIDVIEW;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox BILL_DATE;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label gender;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox BILL_PAT_ID;
        private System.Windows.Forms.TextBox BILL_TOTALAMT;
        private System.Windows.Forms.TextBox BILL_iD;
        private System.Windows.Forms.Button button3;
    }
}
