﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HOSPITAL_MANAGEMENT
{
    public partial class Doctors : UserControl
    {
        public Doctors()
        {
            InitializeComponent();
        }


        private void populate()
        {
            Con.Open();
            string query = "select * from DOCTORS";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            DOC_GV.DataSource = ds.Tables[0];
            Con.Close();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True");


        private void button1_Click(object sender, EventArgs e)
        {
            if (DOC_ID.Text == "" || DOC_LN.Text == "" || DOC_SPE.Text == "" || DOC_FN.Text == "")
            {
                MessageBox.Show("Information is Missing");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "insert into DOCTORS values('" + DOC_ID.Text + "','" + DOC_FN.Text + "','" + DOC_LN.Text + "', '" + DOC_DFB.Text + "', '" + DOC_GEN.Text + "','" + DOC_CNUM.Text + "','" + DOC_ADDR.Text + "','" + DOC_EMAL.Text + "','" + DOC_SPE.Text + "','" + DOC_DEP.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("data added ");
                    Con.Close();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
                Con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (DOC_ID.Text != "" && DOC_FN.Text != "")
            {
                SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True");

                cmd = new SqlCommand("update  DOCTORS set FIRSTNAME=@FN,LASTNAME=@LN, DATEOFBIRTH=@DOB,GENDER=@GE,CONTACTNUMBER=@CN,ADDRESS=@AD,EMAIL=@EM,specialization=@SP,DEPARTMENT=@DP where DOCTORID=@Id", Con);
                Con.Open();
                cmd.Parameters.AddWithValue("@Id", DOC_ID.Text);
                cmd.Parameters.AddWithValue("@FN", DOC_FN.Text);
                cmd.Parameters.AddWithValue("@LN", DOC_LN.Text);
                cmd.Parameters.AddWithValue("@DOB", DOC_DFB.Text);
                cmd.Parameters.AddWithValue("@GE", DOC_GEN.Text);
                cmd.Parameters.AddWithValue("@CN", DOC_CNUM.Text);
                cmd.Parameters.AddWithValue("@AD", DOC_ADDR.Text);
                cmd.Parameters.AddWithValue("@EM", DOC_EMAL.Text);
                cmd.Parameters.AddWithValue("@SP", DOC_SPE.Text);
                cmd.Parameters.AddWithValue("@DP", DOC_DEP.Text);

                cmd.ExecuteNonQuery();
                Con.Close();
                MessageBox.Show("Details Updated Successfully");
                populate();
            }
            else
            {
                MessageBox.Show("Please enter mandatory details!");
            }
        }

        public SqlCommand cmd { get; set; }

        private void Doctors_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            REPORT rv = new REPORT();
            rv.Show();
            Con.Open();
            SqlCommand cmd = new SqlCommand("Select * from doctors", Con);
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sd.Fill(ds, "doctors");
            CrystalReport4 cr = new CrystalReport4();
            cr.SetDataSource(ds);
            rv.crystalReportViewer1.ReportSource = cr;
            rv.crystalReportViewer1.Refresh();
            Con.Close();
        }
    }
}
