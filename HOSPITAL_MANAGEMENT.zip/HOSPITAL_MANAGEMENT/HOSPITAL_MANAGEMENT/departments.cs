﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HOSPITAL_MANAGEMENT
{
    public partial class departments : UserControl
    {
        public departments()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True");
        private void populate()
        {
            Con.Open();
            string query = "select * from departments";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            DEP_GRD.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (DEP_ID.Text == "" || DEP_NAM.Text == "")
            {
                MessageBox.Show("Information is Missing");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "insert into DEPARTMENTS values('" + DEP_ID.Text + "','" + DEP_NAM.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("data added ");
                   
                    Con.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
                Con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (DEP_NAM.Text != "" && DEP_ID.Text != "")
            {
                SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True");

                cmd = new SqlCommand("update  DEPARTMENTS set DEPARTMENTNAME=@DEPNAM where DEPARTMENTID=@Id", Con);
                Con.Open();
                cmd.Parameters.AddWithValue("@Id", DEP_ID.Text);
                cmd.Parameters.AddWithValue("@DEPNAM", DEP_NAM.Text);

                cmd.ExecuteNonQuery();
                Con.Close();
                MessageBox.Show("Details Updated Successfully");
                populate();
            }
            else
            {
                MessageBox.Show("Please enter mandatory details!");
            }
        }

        public SqlCommand cmd { get; set; }

        private void departments_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            REPORT rv = new REPORT();
            rv.Show();
            Con.Open();
            SqlCommand cmd = new SqlCommand("Select * from departments", Con);
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sd.Fill(ds, "departments");
            CrystalReport3 cr = new CrystalReport3();
            cr.SetDataSource(ds);
            rv.crystalReportViewer1.ReportSource = cr;
            rv.crystalReportViewer1.Refresh();
            Con.Close();
        }
    }
}
