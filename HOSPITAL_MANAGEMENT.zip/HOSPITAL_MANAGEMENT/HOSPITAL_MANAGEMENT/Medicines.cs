﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HOSPITAL_MANAGEMENT
{
    public partial class Medicines : UserControl
    {
        public Medicines()
        {
            InitializeComponent();
        }

        private void populate()
        {
            Con.Open();
            string query = "select * from MEDICINES";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            MED_GV.DataSource = ds.Tables[0];
            Con.Close();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True");

        private void button1_Click(object sender, EventArgs e)
        {
            if (MED_ID.Text == "" || MED_MENUF.Text == "" || MED_Q.Text == "" || MED_UP.Text == "")
            {
                MessageBox.Show("Information is Missing");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "insert into MEDICINES values('" + MED_ID.Text + "','" + MED_NAM.Text + "','" + MED_MENUF.Text + "', '" + MED_UP.Text + "', '" + MED_Q.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("data added ");
                    Con.Close();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
                Con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MED_ID.Text != "" && MED_MENUF.Text != "")
            {
                SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True");

                cmd = new SqlCommand("update  MEDICINES set MEDICINENAME=@MN,MANUFACTURER=@MF, UNITPRICE=@UP,QUANTITYINSTOCK=@QNS where MEDICINEID=@Id", Con);
                Con.Open();
                cmd.Parameters.AddWithValue("@Id", MED_ID.Text);
                cmd.Parameters.AddWithValue("@MN", MED_NAM.Text);
                cmd.Parameters.AddWithValue("@MF", MED_MENUF.Text);
                cmd.Parameters.AddWithValue("@UP", MED_UP.Text);
                cmd.Parameters.AddWithValue("@QNS", MED_Q.Text);
                cmd.ExecuteNonQuery();
                Con.Close();
                MessageBox.Show("Details Updated Successfully");
                populate();
            }
            else
            {
                MessageBox.Show("Please enter mandatory details!");
            }
        }

        public SqlCommand cmd { get; set; }

        private void Medicines_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void MED_NAM_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            REPORT rv = new REPORT();
            rv.Show();
            Con.Open();
            SqlCommand cmd = new SqlCommand("Select * from medicines", Con);
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sd.Fill(ds, "medicines");
            CrystalReport5 cr = new CrystalReport5();
            cr.SetDataSource(ds);
            rv.crystalReportViewer1.ReportSource = cr;
            rv.crystalReportViewer1.Refresh();
            Con.Close();
        }
    }
}
