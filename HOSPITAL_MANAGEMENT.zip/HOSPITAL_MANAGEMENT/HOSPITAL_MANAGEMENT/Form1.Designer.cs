﻿namespace HOSPITAL_MANAGEMENT
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.INPASS = new System.Windows.Forms.TextBox();
            this.INUSER = new System.Windows.Forms.TextBox();
            this.EXITBTN = new System.Windows.Forms.Button();
            this.LOGinBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Red;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label2.Location = new System.Drawing.Point(69, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 23);
            this.label2.TabIndex = 27;
            this.label2.Text = "Password";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Red;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label1.Location = new System.Drawing.Point(69, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 23);
            this.label1.TabIndex = 26;
            this.label1.Text = "UserName";
            // 
            // INPASS
            // 
            this.INPASS.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.INPASS.Location = new System.Drawing.Point(184, 63);
            this.INPASS.Name = "INPASS";
            this.INPASS.PasswordChar = '*';
            this.INPASS.Size = new System.Drawing.Size(203, 33);
            this.INPASS.TabIndex = 25;
            // 
            // INUSER
            // 
            this.INUSER.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.INUSER.Location = new System.Drawing.Point(184, 20);
            this.INUSER.Name = "INUSER";
            this.INUSER.Size = new System.Drawing.Size(203, 33);
            this.INUSER.TabIndex = 24;
            // 
            // EXITBTN
            // 
            this.EXITBTN.BackColor = System.Drawing.Color.Red;
            this.EXITBTN.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.EXITBTN.FlatAppearance.BorderSize = 0;
            this.EXITBTN.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.EXITBTN.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.EXITBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EXITBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EXITBTN.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.EXITBTN.Location = new System.Drawing.Point(401, 201);
            this.EXITBTN.Name = "EXITBTN";
            this.EXITBTN.Size = new System.Drawing.Size(130, 35);
            this.EXITBTN.TabIndex = 23;
            this.EXITBTN.Text = "EXIT ";
            this.EXITBTN.UseVisualStyleBackColor = false;
            this.EXITBTN.Click += new System.EventHandler(this.EXITBTN_Click);
            // 
            // LOGinBTN
            // 
            this.LOGinBTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.LOGinBTN.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.LOGinBTN.FlatAppearance.BorderSize = 0;
            this.LOGinBTN.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.LOGinBTN.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.LOGinBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LOGinBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LOGinBTN.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LOGinBTN.Location = new System.Drawing.Point(252, 127);
            this.LOGinBTN.Name = "LOGinBTN";
            this.LOGinBTN.Size = new System.Drawing.Size(135, 37);
            this.LOGinBTN.TabIndex = 22;
            this.LOGinBTN.Text = "LOGIN";
            this.LOGinBTN.UseVisualStyleBackColor = false;
            this.LOGinBTN.Click += new System.EventHandler(this.LOGinBTN_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(601, 256);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.INPASS);
            this.Controls.Add(this.INUSER);
            this.Controls.Add(this.EXITBTN);
            this.Controls.Add(this.LOGinBTN);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox INPASS;
        private System.Windows.Forms.TextBox INUSER;
        private System.Windows.Forms.Button EXITBTN;
        private System.Windows.Forms.Button LOGinBTN;
    }
}

